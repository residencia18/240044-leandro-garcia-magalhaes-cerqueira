# Residevs-PI-P017-TIC18
Este repositório tem como objetivo fazer parte da atividade PI-P017.

Membros da equipe:

Leandro Garcia
Carlos André Dias
Lorena Andrade
Náthalie Lima
Daniel Oliveira
